# Fake News Detection

A simple machine learning project that detects whether a given news article is real or fake using TF-IDF vectorization and Passive Aggressive Classifier. Includes a Flask web app for interactive use.
